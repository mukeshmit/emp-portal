<div class="col-md-3 col-sm-3 col-xs-12 abosDiv hidden-xs widd22">
	<div class="col-md-12 col-sm-12 col-xs-12 bsdivll logoDiv aboshadow hiddSm">
		<div class="logoSecond" style="float:left;">
			<img src="<?php echo Yii::getAlias('@web').'/themes/portal-front/images/nouser.jpg'; ?>" alt="logo man pic" class="img-responsive" style="float:left;">
		</div>
		<div class="logoanthrtext">
			<h1><?php echo Yii::$app->user->isGuest ? 'Guest' : ucfirst(Yii::$app->user->identity->username); ?></h1>
			<p>Welcome to Portal Content</p>
		</div>
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12 aboshadow caleDiv">
		<div class="col-md-12 calarea">
			<h2>Calendars</h2>
			<ul class="empired">
			<li class="empier"> <i class="fa fa-square" aria-hidden="true"></i>Empire</li>
			<li class="pdc"> <i class="fa fa-square" aria-hidden="true"></i>PDC</li>
			<li class="general"> <i class="fa fa-square" aria-hidden="true"></i>General</li>
			</ul>
		</div>
		<div class="btmTest1">
			<div class="maiDate1">
				<p>Friday</p>
				<h2>11</h2>
				<span class="monthapril">April</span>
			</div>
			<div class="DayDesc1">
				<div class="DayDesc12">
					<div class="dayTime">
						10:00 AM
					</div>
					<div class="daywork1">
						<span>Bagels </span><br>
						<span>In main kitchen</span>
					</div>
				</div>
				<div class="DayDesc12">
					<div class="dayTime">
						12:00 PM
					</div>
					<div class="daywork1">
						<span>Happy Hour </span><br>
						<span> @ Lounge </span>
					</div>
				</div>
				<div class="DayDesc12">
					<div class="dayTime">
						1:00 PM
					</div>
					<div class="daywork33">
						<span>Bagels </span><br>
						<span>In main kitchen</span>
					</div>
				</div>
				<div class="DayDesc12">
					<div class="dayTime">
						7:00 PM
					</div>
					<div class="daywork34">
						<span>Cleanup Day</span><br>
						<span> Clean your space </span>
					</div>
				</div>
				<a style="cursor:pointer"><img src="<?php echo Yii::getAlias('@web').'/themes/portal-front/images/arrow-box.jpg'; ?>" id="toggleProfile" class="img-responsive imageArrw" alt="Arrow Icon"></a>
			</div>
		</div>
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12 paddingZ">
		<div class="col-md-12 col-sm-12 col-xs-12 paddingZ">
			<img src="<?php echo Yii::getAlias('@web').'/themes/portal-front/images/comment-boxes.jpg'; ?>" class="img-responsive commentbox">
		</div>
		<div class="col-md-12 col-sm-12 col-xs-12 aboshadow caleDivExt">
			<div class="col-md-12 col-sm-12 col-xs-12 divinpees">
				<form>
					<input type="text" placeholder="" class="inpper1">
					<input type="submit" value="search" class="inppersbmt">
				</form>
			</div>
			<div class="col-md-12 col-sm-12 col-xs-12 paddingZ eklavl">
			</div>
		</div>
	</div>
	<div class="col-md-12 col-sm-12 col-xs-12 paddingZ">
		<div class="col-md-12 col-sm-12 col-xs-12 aboshadow caleDivExtLvl">
			<div class="col-md-12 col-sm-12 col-xs-12 paddingZ">
				<img src="<?php echo Yii::getAlias('@web').'/themes/portal-front/images/comment-logo.jpg'; ?>" class="img-responsive coomntlogo" alt="">
			</div>
			<div class="col-md-12 col-sm-12 col-xs-12 paddingZ">
				<form class="InForm">
					<label>Type:</label>
					<select>
						<option>Type1</option>
						<option>Type2</option>
						<option>Type3</option>
					</select>
					<label>Comment:</label>
					<textarea></textarea>
					<input type="submit" value="Send">
				</form>
			</div>
		</div>
	</div>
</div>