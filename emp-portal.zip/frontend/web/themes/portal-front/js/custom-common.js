

$(".divFixedAn").click(function() {
	$(".divFixed").toggleClass("divFixed1");
});

$(".sliderLink").click(function() {
	$(".item1").addClass("item");
});

$("#toggleProfile").click(function() {
	$(".profile").toggleClass("profile1");
});

$("#toggleProfile1").click(function() {
	$(".profile").toggleClass("profile1");
});

$(".closs").click(function() {
	$(".profile").toggleClass("profile1");
});

$(".divFixedAn").click(function() {
	$(".divFixedAn").toggleClass("divFixedAn1");
});		